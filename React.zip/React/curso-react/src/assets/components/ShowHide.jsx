import React, { useState } from "react";

function ShowHide() {
  const [show, setShow] = useState(true);//useState deveulve un array con 2 elemntos
//primero muestra la variable de donde se guarad el estado y el otro es la funcion que permite cambiar el valor de la variable

//cada vez que se de clic en el boton cambia el valor de show
  const handleClick = (event) => {
    setShow(!show);//cambia el valor de show
  };

  //cuando es verdadero muestra esto Ocultame!
  //cuando le damos clic al boton cambia el show
  return (
    <div>
      <button onClick={handleClick}>{show ? "Hide " : "Show "} Text</button>
      {show && <h2>Ocultame!</h2>}
    </div>
  );
}

export default ShowHide;